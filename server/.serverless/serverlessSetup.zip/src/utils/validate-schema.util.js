"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateSchema = void 0;
function validateSchema(schema, body) {
    var _a = schema.validate(body), value = _a.value, error = _a.error;
    return [value, error];
}
exports.validateSchema = validateSchema;
