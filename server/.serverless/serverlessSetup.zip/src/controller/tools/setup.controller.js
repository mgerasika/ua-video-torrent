"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setup = void 0;
var express_app_1 = require("../../express-app");
var api_url_constant_1 = require("../../constants/api-url.constant");
var get_imdb_list_controller_1 = require("../imdb/get-imdb-list.controller");
var post_imdb_controller_1 = require("../imdb/post-imdb.controller");
var get_movie_list_controller_1 = require("../movie/get-movie-list.controller");
var put_movie_controller_1 = require("../movie/put-movie.controller");
var get_hurtom_all_controller_1 = require("./get-hurtom-all.controller");
var db_service_1 = require("../db.service");
var joi_1 = __importDefault(require("joi"));
var validate_schema_util_1 = require("../../utils/validate-schema.util");
var schema = joi_1.default.object({
    updateHurtom: joi_1.default.boolean().required(),
    updateImdb: joi_1.default.boolean().required(),
    uploadTorrentToS3FromMovieDB: joi_1.default.boolean().required(),
});
express_app_1.app.post(api_url_constant_1.API_URL.api.tools.setup.toString(), function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, validateError, _b, logs, error;
    return __generator(this, function (_c) {
        switch (_c.label) {
            case 0:
                _a = (0, validate_schema_util_1.validateSchema)(schema, req.body), validateError = _a[1];
                if (validateError) {
                    return [2 /*return*/, res.status(400).send(validateError)];
                }
                return [4 /*yield*/, (0, exports.setup)(req.body)];
            case 1:
                _b = _c.sent(), logs = _b[0], error = _b[1];
                if (error) {
                    return [2 /*return*/, res.status(400).send(error)];
                }
                res.send(logs);
                return [2 /*return*/];
        }
    });
}); });
var setup = function (_a) {
    var updateHurtom = _a.updateHurtom, updateImdb = _a.updateImdb, uploadTorrentToS3FromMovieDB = _a.uploadTorrentToS3FromMovieDB;
    return __awaiter(void 0, void 0, void 0, function () {
        var logs, movies, hurtomItems, fns, fns, imdbInfoItems_1, fns;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    logs = [];
                    return [4 /*yield*/, (0, get_movie_list_controller_1.getMoviesAllAsync)()];
                case 1:
                    movies = (_b.sent())[0];
                    if (!updateHurtom) return [3 /*break*/, 4];
                    return [4 /*yield*/, (0, get_hurtom_all_controller_1.getAllHurtomPagesAsync)()];
                case 2:
                    hurtomItems = (_b.sent())[0];
                    if (!hurtomItems) return [3 /*break*/, 4];
                    logs.push("hurtom items received count=".concat(hurtomItems.length));
                    fns = hurtomItems.map(function (hurtomItem) {
                        return function () { return __awaiter(void 0, void 0, void 0, function () {
                            var movie, _a, error, _b, putError;
                            return __generator(this, function (_c) {
                                switch (_c.label) {
                                    case 0:
                                        movie = movies === null || movies === void 0 ? void 0 : movies.find(function (movie) { return movie.href === hurtomItem.href; });
                                        if (!!movie) return [3 /*break*/, 2];
                                        return [4 /*yield*/, db_service_1.dbService.movie.postMovieAsync({
                                                en_name: hurtomItem.enName,
                                                href: hurtomItem.href,
                                                title: hurtomItem.id,
                                                ua_name: hurtomItem.uaName,
                                                year: +hurtomItem.year,
                                                download_id: hurtomItem.downloadId,
                                                aws_s3_torrent_url: '',
                                                size: hurtomItem.size,
                                            })];
                                    case 1:
                                        _a = _c.sent(), error = _a[1];
                                        if (error) {
                                            logs.push("add movie error ".concat(hurtomItem.id, " error=").concat(error));
                                        }
                                        else {
                                            logs.push("add movie success ".concat(hurtomItem.id, " "));
                                        }
                                        return [3 /*break*/, 4];
                                    case 2: return [4 /*yield*/, db_service_1.dbService.movie.putMovieAsync(movie.id, __assign(__assign({}, movie), { size: hurtomItem.size, download_id: hurtomItem.downloadId }))];
                                    case 3:
                                        _b = _c.sent(), putError = _b[1];
                                        if (putError) {
                                            logs.push("update movie error ".concat(hurtomItem.id, " error=").concat(putError));
                                        }
                                        else {
                                            logs.push("update movie success ".concat(hurtomItem.id, " "));
                                        }
                                        _c.label = 4;
                                    case 4: return [2 /*return*/, Promise.resolve()];
                                }
                            });
                        }); };
                    });
                    return [4 /*yield*/, fns.reduce(function (acc, curr) {
                            return acc.then(curr);
                        }, Promise.resolve())];
                case 3:
                    _b.sent();
                    _b.label = 4;
                case 4:
                    if (!uploadTorrentToS3FromMovieDB) return [3 /*break*/, 6];
                    if (!movies) return [3 /*break*/, 6];
                    fns = movies.map(function (movie) {
                        return function () { return __awaiter(void 0, void 0, void 0, function () {
                            var _a, hasFileError, _b, successUpload, errorUpload;
                            return __generator(this, function (_c) {
                                switch (_c.label) {
                                    case 0:
                                        if (!(!movie.aws_s3_torrent_url && movie.download_id)) return [3 /*break*/, 8];
                                        return [4 /*yield*/, db_service_1.dbService.s3.hasFileS3Async({ id: movie.download_id })];
                                    case 1:
                                        _a = _c.sent(), hasFileError = _a[1];
                                        if (!hasFileError) return [3 /*break*/, 5];
                                        return [4 /*yield*/, db_service_1.dbService.s3.uploadFileToAmazonAsync({
                                                hurtomDownloadId: movie.download_id,
                                            })];
                                    case 2:
                                        _b = _c.sent(), successUpload = _b[0], errorUpload = _b[1];
                                        if (successUpload) {
                                            logs.push("success upload to s3", movie.download_id);
                                        }
                                        else {
                                            logs.push("error upload to s3", errorUpload);
                                        }
                                        if (!successUpload) return [3 /*break*/, 4];
                                        return [4 /*yield*/, db_service_1.dbService.movie.putMovieAsync(movie.id, __assign(__assign({}, movie), { aws_s3_torrent_url: successUpload }))];
                                    case 3:
                                        _c.sent();
                                        _c.label = 4;
                                    case 4: return [3 /*break*/, 7];
                                    case 5: return [4 /*yield*/, db_service_1.dbService.movie.putMovieAsync(movie.id, __assign(__assign({}, movie), { aws_s3_torrent_url: movie.download_id }))];
                                    case 6:
                                        _c.sent();
                                        _c.label = 7;
                                    case 7: return [3 /*break*/, 10];
                                    case 8:
                                        if (!!movie.download_id) return [3 /*break*/, 10];
                                        return [4 /*yield*/, (0, put_movie_controller_1.putMovieAsync)(movie.id, __assign(__assign({}, movie), { aws_s3_torrent_url: '' }))];
                                    case 9:
                                        _c.sent();
                                        _c.label = 10;
                                    case 10: return [2 /*return*/, Promise.resolve()];
                                }
                            });
                        }); };
                    });
                    return [4 /*yield*/, fns.reduce(function (acc, curr) {
                            return acc.then(curr);
                        }, Promise.resolve())];
                case 5:
                    _b.sent();
                    _b.label = 6;
                case 6:
                    if (!updateImdb) return [3 /*break*/, 9];
                    return [4 /*yield*/, (0, get_imdb_list_controller_1.getImdbAllAsync)()];
                case 7:
                    imdbInfoItems_1 = (_b.sent())[0];
                    if (!(imdbInfoItems_1 && movies)) return [3 /*break*/, 9];
                    fns = movies.map(function (movieItem) {
                        return function () { return __awaiter(void 0, void 0, void 0, function () {
                            var imdbInfo, _a, error, _b, newInfo, error;
                            return __generator(this, function (_c) {
                                switch (_c.label) {
                                    case 0:
                                        if (!!movieItem.imdb) return [3 /*break*/, 6];
                                        imdbInfo = imdbInfoItems_1.find(function (item) { return item.en_name === movieItem.en_name; });
                                        if (!imdbInfo) return [3 /*break*/, 2];
                                        return [4 /*yield*/, (0, put_movie_controller_1.putMovieAsync)(movieItem.id, __assign(__assign({}, movieItem), { imdb: imdbInfo }))];
                                    case 1:
                                        _a = _c.sent(), error = _a[1];
                                        if (error) {
                                            logs.push("add imdb_id error ".concat(movieItem.id, " error=").concat(error));
                                        }
                                        else {
                                            logs.push("add imdb_id success ".concat(movieItem.id, " "));
                                        }
                                        return [3 /*break*/, 6];
                                    case 2: return [4 /*yield*/, db_service_1.dbService.tools.searchImdbMovieInfoAsync(movieItem.en_name, movieItem.year + '')];
                                    case 3:
                                        _b = _c.sent(), newInfo = _b[0], error = _b[1];
                                        if (!newInfo) return [3 /*break*/, 5];
                                        logs.push("imdb found ".concat(movieItem.en_name));
                                        return [4 /*yield*/, (0, post_imdb_controller_1.postImdbAsync)({
                                                en_name: newInfo.Title,
                                                imdb_rating: +newInfo.imdbRating,
                                                json: JSON.stringify(newInfo),
                                                poster: newInfo.Poster,
                                                year: +newInfo.Year,
                                            })];
                                    case 4:
                                        _c.sent();
                                        _c.label = 5;
                                    case 5:
                                        if (error) {
                                            logs.push("imdb info not found ".concat(movieItem.en_name, " error=").concat(error));
                                        }
                                        _c.label = 6;
                                    case 6: return [2 /*return*/, Promise.resolve()];
                                }
                            });
                        }); };
                    });
                    return [4 /*yield*/, fns.reduce(function (acc, curr) {
                            return acc.then(curr);
                        }, Promise.resolve())];
                case 8:
                    _b.sent();
                    _b.label = 9;
                case 9: return [2 /*return*/, [logs, undefined]];
            }
        });
    });
};
exports.setup = setup;
